#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "ssd.h"

#define _XTAL_FREQ 20000000   // System clock frequency (20 MHz)

/*
 * Global buffer to store RPM as ASCII string
 */
unsigned char rpm_ssd[5];

/*
 * Optional delay variable (currently unused)
 */
int delay = 0;

/*
 * Lookup table for 7-segment display digits
 */
static const unsigned char digit[10] = {
    ZERO, ONE, TWO, THREE, FOUR,
    FIVE, SIX, SEVEN, EIGHT, NINE
}; 

/*
 * Function: get_rpm
 * -----------------
 * Reads ADC value from CHANNEL4,
 * converts it to RPM (0?6000),
 * converts RPM to ASCII string,
 * and transmits via CAN.
 */
uint16_t get_rpm()
{
    uint16_t adc_val = read_adc(CHANNEL4);  // Read ADC value (0?1023)
    
    uint16_t RPM;   // Correct data type (can hold up to 6000)

    // Map ADC value to RPM range (0?6000)
    if(adc_val == 1023){
        RPM = 6000;
    }
    else{
        RPM = ((unsigned long)adc_val * 6000 + 511) / 1023;
    }

    // Convert RPM value to 4-digit ASCII string
    rpm_ssd[0] = (RPM / 1000) + '0';
    rpm_ssd[1] = ((RPM / 100) % 10) + '0';
    rpm_ssd[2] = ((RPM / 10) % 10) + '0';
    rpm_ssd[3] = (RPM % 10) + '0';
    rpm_ssd[4] = '\0';   // Null terminator

    // Transmit RPM data via CAN (4 bytes)
    can_transmit(RPM_MSG_ID, rpm_ssd, 4);

    __delay_ms(80);   // Delay for CAN stability (blocking)
}

/*
 * Function: get_engine_temp
 * -------------------------
 * Placeholder for engine temperature logic
 * (ADC ? temperature conversion to be implemented)
 */
uint16_t get_engine_temp()
{
    // TODO: Implement temperature calculation
}

/*
 * Function: process_indicator
 * ---------------------------
 * Reads keypad input and controls left/right indicators.
 * Also transmits indicator status via CAN.
 */
IndicatorStatus process_indicator()
{
    unsigned char key = read_digital_keypad(STATE_CHANGE);  
    // Read keypad input (state change detection)

    IndicatorStatus status;  
    // Variable to store indicator status

    uint8_t data[1];   // CAN data buffer

    // Determine indicator state based on key press
    if(key == SWITCH1){
        status = e_ind_left;
    }
    else if(key == SWITCH3){
        status = e_ind_right;
    }
    else if(key == SWITCH2){
        status = e_ind_off;
    }

    // Control indicator LEDs using PORTB pins
    if(status == e_ind_left){
        PORTBbits.RB6 = 0;
        PORTBbits.RB7 = 0;
        PORTBbits.RB0 = 1;
        PORTBbits.RB1 = 1;
    }
    else if(status == e_ind_right){
        PORTBbits.RB0 = 0;
        PORTBbits.RB1 = 0;
        PORTBbits.RB6 = 1;
        PORTBbits.RB7 = 1;
    }
    else if(status == e_ind_off){
        PORTBbits.RB0 = 0;
        PORTBbits.RB1 = 0;
        PORTBbits.RB6 = 0;
        PORTBbits.RB7 = 0;
    }

    // Prepare CAN data (indicator status)
    data[0] = status;

    // Transmit indicator status via CAN (1 byte)
    can_transmit(INDICATOR_MSG_ID, data, 1);

    __delay_ms(80);   // Delay for debounce and CAN timing
}