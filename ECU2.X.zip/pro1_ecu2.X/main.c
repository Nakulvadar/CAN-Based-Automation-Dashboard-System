/*
 * File:   main.c
 * Author: nakul
 *
 * Created on 1 April, 2026, 10:49 AM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "clcd.h"
#include "ssd.h"

void init_config()
{
    //configuring LEDS for indicator.
    TRISB0 = 0;
    TRISB1 = 0;
    TRISB6 = 0;
    TRISB7 = 0;
    PORTBbits.RB0 = 0;
    PORTBbits.RB1 = 0;
    PORTBbits.RB6 = 0;
    PORTBbits.RB7 = 0;
    
    //configuring SSD for display RPM. 
    TRISD = 0x00;
    PORTD = 0x00;
    TRISA = TRISA & 0xf0;
    
    init_adc();
//    init_clcd();
    init_can();
//    init_uart();
}


int main()
{
    unsigned int RPM;
    //call the functions
    init_config();
    
    // Lookup table
    
    while(1){
        
        get_rpm();
         
        process_indicator();
    }
}
