#include "ssd.h"


void Display_SSD(char SSD[])
{
    for(int data =0; data < 4; data++){
       
        PORTD = SSD[data];
        PORTA = (PORTA & 0xf0) | (1 << data);
        
        //giving same delay for better visibility 
        for(unsigned long int delay = 1000; delay--;);
    }
}
        
