#ifndef SSD_H
#define SSD_H

#include <xc.h>

// 7-segment encoding
#define ZERO    0xe7
#define ONE     0x21
#define TWO     0xcb
#define THREE   0x6b
#define FOUR    0x2d
#define FIVE    0x6e
#define SIX     0xee
#define SEVEN   0x23
#define EIGHT   0xef
#define NINE    0x6f

void Display_SSD(char SSD[]); 

#endif