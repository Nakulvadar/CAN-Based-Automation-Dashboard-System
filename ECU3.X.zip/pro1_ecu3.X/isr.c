/*
 * File:   isr.c
 * Author: nakul
 *
 * Created on 6 April, 2026, 11:30 PM
 */


#include "isr.h"
#include <xc.h>

int count ;

void __interrupt() isr(void)
{
    //if TMR0IF set as 1.
    if(TMR0IF){
        
        TMR0 = TMR0 + 8; // 8 for 8bit and 3038 for 16bit.
        
        TMR0IF = 0; //reseting Flag.
        if(count++ == 20000){ // 5000 1:4 for 8bit and 20 1:4 for 16bit.
            count =0;      //reset counter to 0; for next interrupt.            
        }
    }
}