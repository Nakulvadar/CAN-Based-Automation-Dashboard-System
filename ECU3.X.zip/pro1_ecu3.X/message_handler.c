#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

/*
 * External variable used for timing (indicator blinking control)
 */
extern int count;

/*
 * Global indicator states
 */
volatile unsigned char led_state = LED_OFF, status = e_ind_off;

/*
 * Function: handle_speed_data
 * ---------------------------
 * Receives speed data from CAN and displays it on CLCD.
 */
void handle_speed_data(uint8_t *data, uint8_t len)
{
    clcd_print("SPD ", LINE1(0));   // Display label
    data[2] = '\0';                 // Ensure string termination (2 digits)
    clcd_print(data, LINE2(0));     // Display speed value
}

/*
 * Function: handle_gear_data
 * --------------------------
 * Receives gear data from CAN and displays it on CLCD.
 */
void handle_gear_data(uint8_t *data, uint8_t len) 
{
    clcd_print("GEAR ", LINE1(4));  // Display label
    data[2] = '\0';                 // Ensure string termination
    clcd_print(data, LINE2(4));     // Display gear value
}

/*
 * Function: handle_rpm_data
 * -------------------------
 * Receives RPM data from CAN and displays it on CLCD.
 */
void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    clcd_print("RPM ", LINE1(9));   // Display label
    data[4] = '\0';                 // Ensure string termination (4 digits)
    clcd_print(data, LINE2(8));     // Display RPM value
}

/*
 * Function: handle_indicator_data
 * -------------------------------
 * Receives indicator status from CAN,
 * controls LEDs and updates CLCD display.
 */
void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    IndicatorStatus status = data[0];   // Extract indicator status

    clcd_print("IND", LINE1(13));       // Display label

    if(status == e_ind_left)
    {
        if(count < 10000)   // Blink condition
        {
            RIGHT_IND_OFF();
            LEFT_IND_ON();
            clcd_print("<-", LINE2(14)); 
        }
        else
        {
            RIGHT_IND_OFF();
            LEFT_IND_OFF();
        }
    }
    else if(status == e_ind_right)
    {
        if(count < 10000)   // Blink condition
        {
            LEFT_IND_OFF();
            RIGHT_IND_ON();
            clcd_print("->", LINE2(14)); 
        }
        else
        {
            RIGHT_IND_OFF();
            LEFT_IND_OFF();
        }
    }
    else if(status == e_ind_off)
    {
        RIGHT_IND_OFF();
        LEFT_IND_OFF();
        clcd_print("--", LINE2(14)); 
    }  
}

/*
 * Global variables for CAN reception
 */
uint16_t msg_id;
uint8_t data[5];
uint8_t len;

/*
 * Function: process_canbus_data
 * -----------------------------
 * Receives CAN message and routes it
 * to the corresponding handler function.
 */
void process_canbus_data() 
{   
    // Receive CAN frame (message ID + data + length)
    can_receive(&msg_id, data, &len);
    
    // Process message based on message ID
    if(msg_id == SPEED_MSG_ID){
        handle_speed_data(data, len);     
    }
    if(msg_id == GEAR_MSG_ID){
        handle_gear_data(data, len);
    }
    if(msg_id == RPM_MSG_ID){
        handle_rpm_data(data, len);
    }
    if(msg_id == INDICATOR_MSG_ID){
        handle_indicator_data(data, len);
    }
}

/*
 * CLCD Layout Reference:
 * ---------------------------------
 * Position:  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16
 * Line1:     S  P  D     G  E  A  R     R  P  M     I  N  D
 */