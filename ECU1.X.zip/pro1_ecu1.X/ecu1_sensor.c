    #include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "clcd.h"
#define _XTAL_FREQ 20000000
//#include "uart.h"

unsigned char get_speed()
{
    // Implement the speed function
    unsigned char speed =0;
    return((read_adc(CHANNEL4)) / 10.33);
}

int index = 0;
char gear_str[9][3] = {"ON","GN","G1","G2","G3","G4","G5","RE","CO"};
unsigned char get_gear_pos()
{
    // Implement the gear function
    
    char gear = read_switch(STATE_CHANGE);
    
    if(gear == 1){
        if(index < 7)
        index++;
    }
    else if(gear == 2){
        if(index > 1)
        index--;
    }
    else if(gear == 3){
        index = 8;
    }
    //transmitting the data through the CAN 
    can_transmit(GEAR_MSG_ID, gear_str[index],2);
    __delay_ms(80);
    
    //Receiving the data through the CAN 
//    can_receive(&ms_id,data,&len);
//    data[2] = '\0';
//    
//    
//    clcd_print("Gear :",LINE2(0));
//    clcd_print(data,LINE2(7));
    return 0;
}

void display_speed(unsigned char speed)
{
    unsigned char str[3];
    uint16_t ms_id;
    uint8_t data[3];
    uint8_t len;
    
    if(speed < 10)
    {
        str[0] = ' ';
        str[1] = speed + '0';
    }
    else
    {
        str[0] = (speed / 10) + '0';
        str[1] = (speed % 10) + '0';
    }
    str[2] = '\0';

    
    //transmitting the data through the CAN 
    can_transmit(SPEED_MSG_ID,str,2);
    __delay_ms(80);
    
//    Receiving the data through the CAN 
//    can_receive(&ms_id,data,&len);
//    data[2] = '\0';
//    
//    clcd_print("SP:", LINE1(0));
//    clcd_print(data, LINE1(3));
}


