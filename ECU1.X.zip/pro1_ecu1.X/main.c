/*
 * File:   main.c
 * Author: nakul
 *
 * Created on 31 March, 2026, 4:40 PM
 */


#include <xc.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include<stdio.h>
#include<string.h>
#include "clcd.h"
#include "uart.h"

static void init_config(void)
{
    TRISB = 0x1E;      // RB1?RB4 input, RB5?RB7 output
    RBPU = 0;
    PORTB = PORTB | 0xE0;
    
    init_adc();
    init_clcd();
    init_can();
    init_uart();
}


int main()
{
    //Call the functions
    init_config();
    unsigned char sp;
    unsigned char gear;
    
    while(1){
        sp = get_speed();
        display_speed(sp);
        
        gear = get_gear_pos();
    }
    
}