#include <xc.h>
#include "digital_keypad.h"
#define _XTAL_FREQ 20000000

void init_digital_keypad(void)
{
	TRISC = TRISC | INPUT_PINS;
}

unsigned char read_digital_keypad(unsigned char detection_type)
{
	static unsigned char once = 1;

	if (detection_type == STATE_CHANGE)
	{
		if (((KEY_PORT & INPUT_PINS) != ALL_RELEASED) && once)
		{
			once = 0;

			return (KEY_PORT & INPUT_PINS);
		}
		else if ((KEY_PORT & INPUT_PINS) == ALL_RELEASED)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL)
	{
		return (KEY_PORT & INPUT_PINS);
	}

	return 0xFF;
}



int switch_scan(void)
{
   // ROW1 active
    ROW1 = 0; ROW2 = 1; ROW3 = 1;
    __delay_us(50);

    if(COL1 == 0) return 1;
    if(COL2 == 0) return 4;
    if(COL3 == 0) return 7;
    if(COL4 == 0) return 10;

    // ROW2 active
    ROW1 = 1; ROW2 = 0; ROW3 = 1;
    __delay_us(50);

    if(COL1 == 0) return 2;
    if(COL2 == 0) return 5;
    if(COL3 == 0) return 8;
    if(COL4 == 0) return 11;

    // ROW3 active
    ROW1 = 1; ROW2 = 1; ROW3 = 0;
    __delay_us(50);

    if(COL1 == 0) return 3;
    if(COL2 == 0) return 6;
    if(COL3 == 0) return 9;
    if(COL4 == 0) return 12;

    return 0; 
}

int read_switch(char type)
{
    static unsigned char once = 1;
    int key = switch_scan();

    if(type == LEVEL)
    {
        return switch_scan();
    }
    else if(type == STATE_CHANGE)
    {
        if(key != 0 && once)
        {
            __delay_ms(20);
            once = 0;
            return switch_scan();
        }
        else if(key == 0)
        {
            once = 1;
        }
    }

    return 0;
}

